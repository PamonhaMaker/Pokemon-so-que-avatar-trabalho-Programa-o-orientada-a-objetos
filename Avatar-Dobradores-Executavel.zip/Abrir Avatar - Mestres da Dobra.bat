@echo off
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo.
  echo Java nao foi encontrado neste computador.
  echo Instale o Java JDK/JRE e tente novamente.
  echo.
  pause
  exit /b 1
)
java -jar "Avatar-Dobradores.jar"
if errorlevel 1 (
  echo.
  echo O programa encontrou um erro ao iniciar.
  echo.
  pause
)
