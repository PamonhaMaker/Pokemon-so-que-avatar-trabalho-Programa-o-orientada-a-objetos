import modelo.*;

public class TesteManual {
    public static void main(String[] args) {
        Dobrador zuko = new Zuko();
        Dobrador katara = new Katara();
        Dobrador toph = new Toph();
        Dobrador azula = new Azula();
        Dobrador aang = new Aang();

        System.out.println("=== Fogo vs Ar ===");
        zuko.atacar(aang);
        System.out.println("\n=== Fogo vs Água ===");
        zuko.atacar(katara);
        System.out.println("\n=== Terra vs Água ===");
        toph.atacar(katara);
        System.out.println("\n=== Azula ===");
        azula.atacar(toph);
        System.out.println("\n=== Aang ===");
        aang.atacar(zuko);
    }
}
