package gui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import modelo.Dobrador;
import sistema.Mestre;
import sistema.RegistroDobradores;
import sistema.Recrutamento;

/** Janela de confronto entre o seu dobrador e um mestre encontrado. */
public class TelaEncontro extends JFrame {
    private final Dobrador dobradorSelvagem;
    private final Mestre mestre;
    private final RegistroDobradores registro;
    private Dobrador dobradorAtivo;

    private JProgressBar barraInimigo;
    private JLabel labelChance;
    private JLabel labelImagemAtiva;
    private JLabel labelNomeAtiva;
    private JProgressBar barraAtiva;
    private JButton botaoAtacar;
    private JButton botaoRecrutar;

    public TelaEncontro(Dobrador encontrado, String regiao, Mestre mestre, RegistroDobradores registro) {
        super("Confronto — " + encontrado.getNome());
        this.dobradorSelvagem = encontrado;
        this.mestre = mestre;
        this.registro = registro;
        registro.registrarComoVisto(encontrado);
        dobradorAtivo = escolherDobradorAtivo("Quem vai enfrentar " + encontrado.getNome() + "?");

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(470,680);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));

        JLabel titulo=new JLabel("<html><center>⚡ Um dobrador apareceu em "+regiao+"!</center></html>",SwingConstants.CENTER);
        titulo.setFont(new Font("Arial",Font.BOLD,17));
        titulo.setBorder(BorderFactory.createEmptyBorder(10,10,0,10));
        add(titulo,BorderLayout.NORTH);

        JPanel centro=new JPanel();
        centro.setLayout(new BoxLayout(centro,BoxLayout.Y_AXIS));
        centro.add(criarPainelInimigo());
        centro.add(Box.createVerticalStrut(10));
        centro.add(new JSeparator());
        centro.add(Box.createVerticalStrut(10));
        centro.add(criarPainelAtivo());
        add(centro,BorderLayout.CENTER);
        add(criarBotoes(),BorderLayout.SOUTH);
        atualizarBotoes();
    }

    private JPanel criarPainelInimigo() {
        JPanel p=new JPanel();
        p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        String caminho="/imagens/dobradores/"+dobradorSelvagem.getClass().getSimpleName().toLowerCase()+".png";
        JLabel img=new JLabel(CarregadorImagem.carregar(caminho,150,150,dobradorSelvagem.getNome(),new Color(180,100,80)));
        img.setAlignmentX(Component.CENTER_ALIGNMENT); p.add(img);
        JLabel nome=new JLabel(dobradorSelvagem.getNome()+" ["+dobradorSelvagem.getTipo()+"] Nv."+dobradorSelvagem.getNivel(),SwingConstants.CENTER);
        nome.setFont(new Font("Arial",Font.BOLD,15)); nome.setAlignmentX(Component.CENTER_ALIGNMENT); p.add(nome);
        barraInimigo=new JProgressBar(0,dobradorSelvagem.getVidaMaxima()); barraInimigo.setStringPainted(true);
        barraInimigo.setMaximumSize(new Dimension(280,22)); barraInimigo.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(Box.createVerticalStrut(6)); p.add(barraInimigo);
        JLabel habilidade=new JLabel("<html><center><i>"+dobradorSelvagem.descricaoHabilidade()+"</i></center></html>");
        habilidade.setAlignmentX(Component.CENTER_ALIGNMENT); habilidade.setBorder(BorderFactory.createEmptyBorder(6,15,0,15)); p.add(habilidade);
        labelChance=new JLabel("",SwingConstants.CENTER); labelChance.setAlignmentX(Component.CENTER_ALIGNMENT);
        p.add(Box.createVerticalStrut(5)); p.add(labelChance);
        atualizarBarraInimigo();
        return p;
    }

    private JPanel criarPainelAtivo() {
        JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS));
        JLabel titulo=new JLabel("Seu dobrador",SwingConstants.CENTER);
        titulo.setFont(new Font("Arial",Font.BOLD,14)); titulo.setAlignmentX(Component.CENTER_ALIGNMENT); p.add(titulo);
        labelImagemAtiva=new JLabel(); labelImagemAtiva.setAlignmentX(Component.CENTER_ALIGNMENT); p.add(labelImagemAtiva);
        labelNomeAtiva=new JLabel("",SwingConstants.CENTER); labelNomeAtiva.setFont(new Font("Arial",Font.BOLD,14));
        labelNomeAtiva.setAlignmentX(Component.CENTER_ALIGNMENT); p.add(labelNomeAtiva);
        barraAtiva=new JProgressBar(); barraAtiva.setStringPainted(true); barraAtiva.setMaximumSize(new Dimension(280,22));
        barraAtiva.setAlignmentX(Component.CENTER_ALIGNMENT); p.add(barraAtiva);
        atualizarPainelAtivo();
        return p;
    }

    private Dobrador escolherDobradorAtivo(String mensagem) {
        List<Dobrador> disponiveis=new ArrayList<>();
        for(Dobrador d:mestre.getEquipe()) if(!d.estaDerrotada()) disponiveis.add(d);
        if(disponiveis.isEmpty()) return null;
        if(disponiveis.size()==1) return disponiveis.get(0);
        String[] opcoes=new String[disponiveis.size()];
        for(int i=0;i<disponiveis.size();i++){
            Dobrador d=disponiveis.get(i);
            opcoes[i]=d.getNome()+" ["+d.getTipo()+"] HP "+d.getVida()+"/"+d.getVidaMaxima();
        }
        int escolha=JOptionPane.showOptionDialog(this,mensagem,"Escolha o dobrador",
            JOptionPane.DEFAULT_OPTION,JOptionPane.PLAIN_MESSAGE,null,opcoes,opcoes[0]);
        return escolha<0?disponiveis.get(0):disponiveis.get(escolha);
    }

    private void atualizarBarraInimigo() {
        barraInimigo.setValue(dobradorSelvagem.getVida());
        barraInimigo.setString("HP: "+dobradorSelvagem.getVida()+"/"+dobradorSelvagem.getVidaMaxima());
        labelChance.setText(String.format("Chance de recrutamento: %.1f%%",Recrutamento.calcularChance(dobradorSelvagem)*100));
    }

    private void atualizarPainelAtivo() {
        if(dobradorAtivo==null){
            labelImagemAtiva.setIcon(CarregadorImagem.carregar("",100,100,"-",Color.GRAY));
            labelNomeAtiva.setText("Não há dobradores prontos para lutar.");
            barraAtiva.setMaximum(1); barraAtiva.setValue(0); barraAtiva.setString("--"); return;
        }
        String caminho="/imagens/dobradores/"+dobradorAtivo.getClass().getSimpleName().toLowerCase()+".png";
        labelImagemAtiva.setIcon(CarregadorImagem.carregar(caminho,120,120,dobradorAtivo.getNome(),new Color(70,130,180)));
        labelNomeAtiva.setText(dobradorAtivo.getNome()+" ["+dobradorAtivo.getTipo()+"] Nv."+dobradorAtivo.getNivel());
        barraAtiva.setMaximum(dobradorAtivo.getVidaMaxima()); barraAtiva.setValue(dobradorAtivo.getVida());
        barraAtiva.setString("HP: "+dobradorAtivo.getVida()+"/"+dobradorAtivo.getVidaMaxima());
    }

    private JPanel criarBotoes() {
        JPanel p=new JPanel();
        botaoAtacar=new JButton("⚔️ Usar Dobra");
        botaoAtacar.addActionListener(e->atacar());
        botaoRecrutar=new JButton("🤝 Recrutar");
        botaoRecrutar.addActionListener(e->tentarRecrutar());
        JButton fugir=new JButton("🏃 Recuar"); fugir.addActionListener(e->dispose());
        p.add(botaoAtacar); p.add(botaoRecrutar); p.add(fugir);
        return p;
    }

    private void atacar() {
        if(dobradorAtivo==null) return;
        int dano=dobradorAtivo.atacar(dobradorSelvagem);
        atualizarBarraInimigo();
        if(dobradorSelvagem.estaDerrotada()){
            JOptionPane.showMessageDialog(this,dobradorSelvagem.getNome()+" foi derrotado! "+
                dobradorAtivo.getNome()+" ganhou experiência.");
            dispose(); return;
        }
        dobradorSelvagem.atacar(dobradorAtivo);
        atualizarPainelAtivo();
        if(dobradorAtivo.estaDerrotada()){
            Dobrador proximo=escolherDobradorAtivo("Escolha o próximo dobrador:");
            if(proximo==null){
                JOptionPane.showMessageDialog(this,"Toda a equipe está exausta. Vá ao Templo de Cura.");
                dispose(); return;
            }
            dobradorAtivo=proximo; atualizarPainelAtivo();
        }
        atualizarBotoes();
    }

    private void tentarRecrutar() {
        double chance=Recrutamento.calcularChance(dobradorSelvagem)*100;
        boolean sucesso=Recrutamento.tentar(dobradorSelvagem);
        if(sucesso){
            boolean entrou=mestre.adicionarDobrador(dobradorSelvagem);
            registro.registrarComoRecrutado(dobradorSelvagem);
            JOptionPane.showMessageDialog(this,String.format("Chance: %.1f%%.%n%n",chance)+
                dobradorSelvagem.getNome()+" aceitou se juntar à equipe! 🌟"+
                (entrou?"":"\nSua equipe está cheia — ele foi apenas registrado."));
        } else {
            JOptionPane.showMessageDialog(this,String.format("Chance: %.1f%%.%n%n",chance)+
                dobradorSelvagem.getNome()+" recusou o convite e foi embora!");
        }
        dispose();
    }

    private void atualizarBotoes() {
        boolean vivo=!dobradorSelvagem.estaDerrotada();
        botaoAtacar.setEnabled(vivo && dobradorAtivo!=null);
        botaoRecrutar.setEnabled(vivo);
    }
}
