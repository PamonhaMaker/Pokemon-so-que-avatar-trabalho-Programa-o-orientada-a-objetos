package gui;

import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.net.URL;

/**
 * Carrega uma imagem do classpath (pasta "imagens" dentro de src).
 * Se o arquivo ainda não existir, desenha um círculo colorido com a
 * inicial do nome, só pra não quebrar a tela enquanto você não
 * colocou as fotos de verdade ainda.
 */
public class CarregadorImagem {

    public static ImageIcon carregar(String caminhoNoClasspath, int largura, int altura,
                                      String textoFallback, Color corFallback) {
        URL url = CarregadorImagem.class.getResource(caminhoNoClasspath);
        if (url != null) {
            ImageIcon original = new ImageIcon(url);
            BufferedImage recortada = recortarQuadradoCentral(original.getImage());
            Image escalada = recortada.getScaledInstance(largura, altura, Image.SCALE_SMOOTH);
            return new ImageIcon(escalada);
        }
        return criarPlaceholder(largura, altura, textoFallback, corFallback);
    }

    /**
     * Recorta o centro da imagem original num quadrado, usando o menor
     * lado como referência. Isso evita distorcer imagens retangulares
     * (tipo uma arte de vila bem mais larga que alta) quando depois
     * escalamos pro tamanho quadrado do botão/ícone.
     */
    private static BufferedImage recortarQuadradoCentral(Image imagemOriginal) {
        int largura = imagemOriginal.getWidth(null);
        int altura = imagemOriginal.getHeight(null);
        int lado = Math.min(largura, altura);
        int x = (largura - lado) / 2;
        int y = (altura - lado) / 2;

        BufferedImage bufferizada = new BufferedImage(largura, altura, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = bufferizada.createGraphics();
        g.drawImage(imagemOriginal, 0, 0, null);
        g.dispose();

        return bufferizada.getSubimage(x, y, lado, lado);
    }

    private static ImageIcon criarPlaceholder(int largura, int altura, String texto, Color cor) {
        BufferedImage img = new BufferedImage(largura, altura, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(cor);
        g.fillOval(4, 4, largura - 8, altura - 8);
        g.setColor(Color.WHITE);
        g.setFont(new Font("Arial", Font.BOLD, altura / 3));
        FontMetrics fm = g.getFontMetrics();
        String inicial = (texto == null || texto.isEmpty()) ? "?" : texto.substring(0, 1).toUpperCase();
        int x = (largura - fm.stringWidth(inicial)) / 2;
        int y = (altura - fm.getHeight()) / 2 + fm.getAscent();
        g.drawString(inicial, x, y);
        g.dispose();
        return new ImageIcon(img);
    }
}
