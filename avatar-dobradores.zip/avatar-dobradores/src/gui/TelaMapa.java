package gui;

import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;
import modelo.*;
import sistema.Mestre;
import sistema.RegistroDobradores;

/** Tela principal: o jogador explora as regiões do mundo de Avatar. */
public class TelaMapa extends JFrame {
    private final Mestre mestre;
    private final RegistroDobradores registro;

    public TelaMapa() {
        super("Avatar: Mestres da Dobra | A Lenda de Aang");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 680);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10,10));

        mestre = new Mestre("Aventureiro");
        registro = new RegistroDobradores();

        Dobrador starter = escolherStarter();
        mestre.adicionarDobrador(starter);
        registro.registrarComoRecrutado(starter);

        JPanel topo = new JPanel(new BorderLayout());
        JLabel titulo = new JLabel("🌪️ MUNDO DE AVATAR — escolha uma região para explorar", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 21));
        topo.add(titulo, BorderLayout.NORTH);

        JPanel botoes = new JPanel();
        JButton equipe = new JButton("👥 Minha Equipe");
        equipe.addActionListener(e -> mostrarEquipe());
        JButton registroBtn = new JButton("📖 Registro de Dobradores");
        registroBtn.addActionListener(e -> mostrarRegistro());
        JButton templo = new JButton("🛕 Templo de Cura");
        templo.addActionListener(e -> curarEquipe());
        JButton liberar = new JButton("🔄 Liberar por cura");
        liberar.addActionListener(e -> trocarDobradorPorCura());
        botoes.add(equipe); botoes.add(registroBtn); botoes.add(templo); botoes.add(liberar);
        topo.add(botoes, BorderLayout.SOUTH);
        topo.setBorder(BorderFactory.createEmptyBorder(12,10,5,10));
        add(topo, BorderLayout.NORTH);

        JPanel regioes = new JPanel(new GridLayout(2,3,15,15));
        regioes.setBorder(BorderFactory.createEmptyBorder(10,20,20,20));
        for (Regiao r : criarRegioes()) regioes.add(criarBotaoRegiao(r));
        add(regioes, BorderLayout.CENTER);
    }

    private Dobrador escolherStarter() {
        String[] opcoes = {
            "🌪️ Aang [AR]", "💧 Katara [ÁGUA]", "🔥 Zuko [FOGO]", "🪨 Toph [TERRA]"
        };
        int escolha = JOptionPane.showOptionDialog(this,
            "Escolha seu primeiro dobrador para iniciar a jornada:",
            "Escolha seu mestre inicial", JOptionPane.DEFAULT_OPTION,
            JOptionPane.PLAIN_MESSAGE, null, opcoes, opcoes[0]);
        switch (escolha) {
            case 1: return new Katara();
            case 2: return new Zuko();
            case 3: return new Toph();
            default: return new Aang();
        }
    }

    private List<Regiao> criarRegioes() {
        return Arrays.asList(
            new Regiao("Tribo da Água do Sul", "/imagens/regioes/tribo_agua_sul.png",
                Arrays.asList(Katara::new, Pakku::new)),
            new Regiao("Tribo da Água do Norte", "/imagens/regioes/tribo_agua_norte.png",
                Arrays.asList(Katara::new, Pakku::new)),
            new Regiao("Omashu", "/imagens/regioes/omashu.png",
                Arrays.asList(Toph::new, Bumi::new)),
            new Regiao("Ba Sing Se", "/imagens/regioes/ba_sing_se.png",
                Arrays.asList(Toph::new, Bumi::new, Jinora::new)),
            new Regiao("Nação do Fogo", "/imagens/regioes/nacao_fogo.png",
                Arrays.asList(Zuko::new, Azula::new, Iroh::new, Roku::new)),
            new Regiao("Templos do Ar", "/imagens/regioes/templos_ar.png",
                Arrays.asList(Aang::new, Jinora::new))
        );
    }

    private JButton criarBotaoRegiao(Regiao regiao) {
        ImageIcon icone = CarregadorImagem.carregar(regiao.getCaminhoImagem(), 145,145,
            regiao.getNome(), new Color(80,130,170));
        JButton botao = new JButton(regiao.getNome(), icone);
        botao.setVerticalTextPosition(SwingConstants.BOTTOM);
        botao.setHorizontalTextPosition(SwingConstants.CENTER);
        botao.setFont(new Font("Arial", Font.PLAIN, 13));
        botao.addActionListener(e -> {
            if (mestre.proximoDobradorDisponivel() == null) {
                JOptionPane.showMessageDialog(this,
                    "Sua equipe está exausta! Visite o Templo de Cura antes de continuar.");
                return;
            }
            Dobrador encontrado = regiao.sortearDobrador();
            new TelaEncontro(encontrado, regiao.getNome(), mestre, registro).setVisible(true);
        });
        return botao;
    }

    private void curarEquipe() {
        if (mestre.curarEquipe()) {
            JOptionPane.showMessageDialog(this,
                "🛕 Sua equipe foi completamente curada!\n\nCuras restantes: " +
                mestre.getCurasRestantes() + "/" + Mestre.getCurasMaximas());
        } else {
            JOptionPane.showMessageDialog(this,
                "O Templo de Cura não tem mais energia disponível nesta sessão.");
        }
    }

    private void trocarDobradorPorCura() {
        List<Dobrador> equipe = mestre.getEquipe();
        if (equipe.size() <= 1) {
            JOptionPane.showMessageDialog(this, "Você precisa manter pelo menos um dobrador na equipe.");
            return;
        }
        String[] opcoes = new String[equipe.size()];
        for (int i=0;i<equipe.size();i++) {
            Dobrador d=equipe.get(i);
            opcoes[i]=d.getNome()+" ["+d.getTipo()+"] HP "+d.getVida()+"/"+d.getVidaMaxima();
        }
        int escolha=JOptionPane.showOptionDialog(this,
            "Escolha um dobrador para liberar em troca de "+
            Mestre.getCurasPorTroca()+" curas extras.\nEssa ação é permanente.",
            "Liberar dobrador", JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
            null, opcoes, opcoes[0]);
        if(escolha<0) return;
        Dobrador d=equipe.get(escolha);
        if(JOptionPane.showConfirmDialog(this,
            "Liberar "+d.getNome()+"?","Confirmar",JOptionPane.YES_NO_OPTION)
            ==JOptionPane.YES_OPTION) {
            if(mestre.trocarDobradorPorCura(d))
                JOptionPane.showMessageDialog(this,
                    d.getNome()+" foi liberado. Curas restantes: "+mestre.getCurasRestantes());
        }
    }

    private void mostrarEquipe() {
        StringBuilder sb=new StringBuilder("========== SUA EQUIPE ==========\n");
        for(int i=0;i<mestre.getEquipe().size();i++) {
            Dobrador d=mestre.getEquipe().get(i);
            sb.append(i+1).append(". ").append(d.getNome()).append(" [")
              .append(d.getTipo()).append("] Nv.").append(d.getNivel())
              .append(" HP: ").append(d.getVida()).append("/").append(d.getVidaMaxima()).append("\n");
        }
        sb.append("\nEquipe: ").append(mestre.tamanhoEquipe()).append("/6");
        JOptionPane.showMessageDialog(this,sb.toString());
    }

    private void mostrarRegistro() {
        StringBuilder sb=new StringBuilder("===== REGISTRO DE DOBRADORES =====\n");
        for(Dobrador d:registro.getVistos()) {
            String marca=registro.jaFoiRecrutado(d)?"[X]":"[ ]";
            sb.append(marca).append(" ").append(d.getNome()).append(" [")
              .append(d.getTipo()).append("]\n");
        }
        sb.append("\nVistos: ").append(registro.totalVistos())
          .append(" | Recrutados: ").append(registro.totalRecrutados());
        JOptionPane.showMessageDialog(this,sb.toString());
    }

}
