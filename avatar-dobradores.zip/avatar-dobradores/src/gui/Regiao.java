package gui;

import java.util.List;
import java.util.function.Supplier;
import modelo.Dobrador;

/** Uma região do mundo de Avatar e os dobradores que podem ser encontrados nela. */
public class Regiao {
    private String nome;
    private String caminhoImagem;
    private List<Supplier<Dobrador>> possiveisDobradores;

    public Regiao(String nome, String caminhoImagem, List<Supplier<Dobrador>> possiveisDobradores) {
        this.nome = nome;
        this.caminhoImagem = caminhoImagem;
        this.possiveisDobradores = possiveisDobradores;
    }

    public Dobrador sortearDobrador() {
        int indice = (int)(Math.random() * possiveisDobradores.size());
        return possiveisDobradores.get(indice).get();
    }

    public String getNome() { return nome; }
    public String getCaminhoImagem() { return caminhoImagem; }
}
