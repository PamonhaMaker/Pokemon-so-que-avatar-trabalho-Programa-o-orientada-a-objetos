package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Avatar Roku. */
public class Roku extends DobradorFogo {
    public Roku() {
        super("Avatar Roku", 200, 52, 30);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return 1.25;
    }

    @Override
    public String descricaoHabilidade() {
        return "Poder do Avatar: +25% de dano em todos os ataques.";
    }
}
