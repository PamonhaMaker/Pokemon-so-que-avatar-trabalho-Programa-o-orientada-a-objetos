package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Zuko. */
public class Zuko extends DobradorFogo {
    public Zuko() {
        super("Zuko", 125, 36, 17);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return this.percentualVida() < 0.5 ? 1.40 : 1.0;
    }

    @Override
    public String descricaoHabilidade() {
        return "Determinação: +40% de dano quando estiver abaixo de 50% de vida.";
    }
}
