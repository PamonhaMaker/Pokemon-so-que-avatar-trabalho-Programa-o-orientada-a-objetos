package modelo;

import tipos.TipoDobra;

/** Classe-base dos dobradores de Fogo. */
public abstract class DobradorFogo extends Dobrador {
    public DobradorFogo(String nome, int vida, int ataque, int defesa) {
        super(nome, TipoDobra.FOGO, vida, ataque, defesa);
    }

    @Override
    public int atacar(Dobrador inimigo) {
        int dano = super.atacar(inimigo);
        System.out.println(nome + " usa dobra de Fogo contra " + inimigo.getNome() + " (" + dano + " de dano)");
        return dano;
    }
}
