package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Rei Bumi. */
public class Bumi extends DobradorTerra {
    public Bumi() {
        super("Rei Bumi", 190, 48, 28);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return this.percentualVida() > 0.5 ? 1.25 : 1.0;
    }

    @Override
    public String descricaoHabilidade() {
        return "Força de Omashu: +25% de dano enquanto estiver acima de 50% de vida.";
    }
}
