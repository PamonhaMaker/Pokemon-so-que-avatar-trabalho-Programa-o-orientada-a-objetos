package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Mestre Pakku. */
public class Pakku extends DobradorAgua {
    public Pakku() {
        super("Mestre Pakku", 175, 45, 25);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return alvo.getTipo() == TipoDobra.FOGO ? 1.30 : 1.0;
    }

    @Override
    public String descricaoHabilidade() {
        return "Lâmina de Gelo: +30% de dano contra dobradores de Fogo.";
    }
}
