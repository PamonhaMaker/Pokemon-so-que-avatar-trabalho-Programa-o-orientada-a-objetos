package modelo;

import tipos.TipoDobra;

/** Classe-base dos dobradores de Ar. */
public abstract class DobradorAr extends Dobrador {
    public DobradorAr(String nome, int vida, int ataque, int defesa) {
        super(nome, TipoDobra.AR, vida, ataque, defesa);
    }

    @Override
    public int atacar(Dobrador inimigo) {
        int dano = super.atacar(inimigo);
        System.out.println(nome + " usa dobra de Ar contra " + inimigo.getNome() + " (" + dano + " de dano)");
        return dano;
    }
}
