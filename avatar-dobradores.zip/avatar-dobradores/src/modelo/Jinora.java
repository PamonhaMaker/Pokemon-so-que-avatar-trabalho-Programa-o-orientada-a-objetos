package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Jinora. */
public class Jinora extends DobradorAr {
    public Jinora() {
        super("Jinora", 120, 31, 19);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return alvo.getTipo() == TipoDobra.TERRA ? 1.30 : 1.0;
    }

    @Override
    public String descricaoHabilidade() {
        return "Mobilidade Aérea: +30% de dano contra dobradores de Terra.";
    }
}
