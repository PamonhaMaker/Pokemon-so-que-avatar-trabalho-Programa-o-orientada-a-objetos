package modelo;

import tipos.TipoDobra;

/** Classe-base dos dobradores de Água. */
public abstract class DobradorAgua extends Dobrador {
    public DobradorAgua(String nome, int vida, int ataque, int defesa) {
        super(nome, TipoDobra.AGUA, vida, ataque, defesa);
    }

    @Override
    public int atacar(Dobrador inimigo) {
        int dano = super.atacar(inimigo);
        System.out.println(nome + " usa dobra de Água contra " + inimigo.getNome() + " (" + dano + " de dano)");
        return dano;
    }
}
