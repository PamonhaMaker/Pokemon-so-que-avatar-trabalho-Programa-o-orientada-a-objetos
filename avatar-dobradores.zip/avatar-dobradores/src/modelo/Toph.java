package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Toph. */
public class Toph extends DobradorTerra {
    public Toph() {
        super("Toph", 105, 30, 20);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return alvo.getDefesa() < this.defesa ? 1.30 : 1.0;
    }

    @Override
    public String descricaoHabilidade() {
        return "Sentido Sísmico: +30% de dano contra alvos com defesa menor que a sua.";
    }
}
