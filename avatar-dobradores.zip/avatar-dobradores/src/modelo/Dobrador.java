package modelo;

import tipos.TipoDobra;

/**
 * Classe base de toda Dobrador do jogo (equivalente à classe Pokemon da
 * especificação original).
 *
 * Agora com "defesa" e dois hooks de habilidade especial, inspirados
 * no padrão Template Method:
 *   - bonusEspecial(alvo): cada Dobrador concreta (Zuko, Katara, etc.)
 *     é OBRIGADA a implementar. É a habilidade única dela.
 *   - efeitoPosAtaque(alvo, dano): opcional, só quem quiser sobrescreve
 *     (ex: drenar vida). Por padrão não faz nada.
 *
 * Encapsulamento: vida e experiência só mudam através de métodos
 * próprios (receberDano()/curar() e ganharExperiencia()). Nunca
 * existe um "setVida()" ou "setExperiencia()" público.
 */
public abstract class Dobrador {

    /** Experiência necessária pra subir de nível é NIVEL * XP_POR_NIVEL. */
    private static final int XP_POR_NIVEL = 100;

    /** Quanto de experiência se ganha ao derrotar um inimigo em combate. */
    private static final int XP_POR_VITORIA = 50;

    protected String nome;
    protected TipoDobra tipo;
    protected int vida;
    protected int vidaMaxima;
    protected int ataque;
    protected int defesa;
    protected int nivel;
    protected int experiencia;

    public Dobrador(String nome, TipoDobra tipo, int vida, int ataque, int defesa) {
        this.nome = nome;
        this.tipo = tipo;
        this.vida = vida;
        this.vidaMaxima = vida;
        this.ataque = ataque;
        this.defesa = defesa;
        this.nivel = 1;
        this.experiencia = 0;
    }

    /**
     * Método final de ataque, usado igual por QUALQUER Dobrador do jogo.
     * A Batalha só chama atacante.atacar(defensor) — nunca precisa
     * saber se é Zuko, Azula, Katara... O polimorfismo mora nos
     * hooks (bonusEspecial / efeitoPosAtaque), não aqui.
     *
     * Quem derrota o inimigo com o ataque ganha experiência (e pode
     * subir de nível na hora — ver ganharExperiencia()).
     */
    public int atacar(Dobrador inimigo) {
        int dano = calcularDano(inimigo);
        inimigo.receberDano(dano);
        efeitoPosAtaque(inimigo, dano);
        if (inimigo.estaDerrotada()) {
            ganharExperiencia(XP_POR_VITORIA);
        }
        return dano;
    }

    /**
     * Fórmula de dano: base (ataque - metade da defesa do alvo) vezes
     * a vantagem de tipo (centralizada em TipoDobra) vezes o bônus
     * especial de cada Dobrador (centralizado aqui, mas o VALOR do bônus
     * vem do polimorfismo de bonusEspecial()).
     */
    protected int calcularDano(Dobrador inimigo) {
        int base = Math.max(1, this.ataque - inimigo.defesa / 2);
        double vantagem = this.tipo.multiplicador(inimigo.tipo);
        double bonus = bonusEspecial(inimigo);
        return Math.max(1, (int) Math.round(base * vantagem * bonus));
    }

    /**
     * A habilidade especial de cada Dobrador. Cada subclasse concreta
     * decide quando e quanto de bônus dar (1.0 = sem bônus).
     */
    protected abstract double bonusEspecial(Dobrador alvo);

    /**
     * Efeito colateral opcional após o ataque (ex: curar a si mesma
     * drenando vida do alvo). Por padrão não faz nada — só quem
     * precisar sobrescreve.
     */
    protected void efeitoPosAtaque(Dobrador alvo, int danoAplicado) {
        // no-op por padrão
    }

    /** Texto curto explicando a habilidade, pra mostrar na UI/log. */
    public abstract String descricaoHabilidade();

    public void receberDano(int dano) {
        if (dano < 0) dano = 0;
        this.vida -= dano;
        if (this.vida < 0) this.vida = 0;
    }

    public void curar(int quantidade) {
        if (quantidade < 0) quantidade = 0;
        this.vida = Math.min(vidaMaxima, this.vida + quantidade);
    }

    public boolean estaDerrotada() {
        return this.vida <= 0;
    }

    public double percentualVida() {
        if (vidaMaxima == 0) return 0.0;
        return (double) vida / (double) vidaMaxima;
    }

    /**
     * Ganha experiência (nunca é setada diretamente de fora). Se
     * acumular o suficiente, sobe de nível automaticamente — pode
     * subir mais de um nível de uma vez se ganhar muita experiência.
     */
    public void ganharExperiencia(int quantidade) {
        if (quantidade <= 0) {
            return;
        }
        this.experiencia += quantidade;
        int necessariaProximoNivel = nivel * XP_POR_NIVEL;
        while (this.experiencia >= necessariaProximoNivel) {
            this.experiencia -= necessariaProximoNivel;
            subirDeNivel();
            necessariaProximoNivel = nivel * XP_POR_NIVEL;
        }
    }

    /**
     * Efeito de subir de nível: fica mais forte e cura totalmente.
     * Privado de propósito — só ganharExperiencia() pode chamar isso,
     * ninguém sobe de nível "na marra" de fora da classe.
     */
    private void subirDeNivel() {
        nivel++;
        ataque += 2;
        defesa += 1;
        vidaMaxima += 10;
        vida = vidaMaxima;
    }

    public String getNome() { return nome; }
    public TipoDobra getTipo() { return tipo; }
    public int getVida() { return vida; }
    public int getVidaMaxima() { return vidaMaxima; }
    public int getAtaque() { return ataque; }
    public int getDefesa() { return defesa; }
    public int getNivel() { return nivel; }
    public int getExperiencia() { return experiencia; }

    /** Quanta experiência falta pra próxima subida de nível. */
    public int getExperienciaProximoNivel() { return nivel * XP_POR_NIVEL; }

    @Override
    public String toString() {
        return nome + " [" + tipo + "] Nv." + nivel + " HP: " + vida + "/" + vidaMaxima;
    }
}
