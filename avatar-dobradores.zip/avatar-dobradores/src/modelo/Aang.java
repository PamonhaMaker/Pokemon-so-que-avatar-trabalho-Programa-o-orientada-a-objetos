package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Aang. */
public class Aang extends DobradorAr {
    public Aang() {
        super("Aang", 180, 48, 24);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return this.percentualVida() > 0.5 ? 1.30 : 1.0;
    }

    @Override
    public String descricaoHabilidade() {
        return "Estado Avatar: +30% de dano enquanto estiver acima de 50% de vida.";
    }
}
