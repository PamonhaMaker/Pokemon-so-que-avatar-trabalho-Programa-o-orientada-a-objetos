package modelo;

import tipos.TipoDobra;

/** Classe-base dos dobradores de Terra. */
public abstract class DobradorTerra extends Dobrador {
    public DobradorTerra(String nome, int vida, int ataque, int defesa) {
        super(nome, TipoDobra.TERRA, vida, ataque, defesa);
    }

    @Override
    public int atacar(Dobrador inimigo) {
        int dano = super.atacar(inimigo);
        System.out.println(nome + " usa dobra de Terra contra " + inimigo.getNome() + " (" + dano + " de dano)");
        return dano;
    }
}
