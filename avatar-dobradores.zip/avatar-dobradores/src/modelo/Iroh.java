package modelo;

/** Mestre Iroh, dobrador de Fogo e grande mentor da Nação do Fogo. */
public class Iroh extends DobradorFogo {
    public Iroh() { super("Iroh", 165, 42, 24); }

    @Override
    protected double bonusEspecial(Dobrador alvo) { return 1.15; }

    @Override
    protected void efeitoPosAtaque(Dobrador alvo, int danoAplicado) {
        curar((int)Math.round(danoAplicado * 0.10));
    }

    @Override
    public String descricaoHabilidade() {
        return "Sabedoria do Dragão: +15% de dano e recupera 10% do dano causado.";
    }
}
