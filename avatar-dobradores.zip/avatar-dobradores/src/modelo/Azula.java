package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Azula. */
public class Azula extends DobradorFogo {
    public Azula() {
        super("Azula", 145, 46, 20);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return alvo.percentualVida() < 0.30 ? 1.50 : 1.0;
    }

    @Override
    public String descricaoHabilidade() {
        return "Relâmpago: +50% de dano contra alvos com menos de 30% de vida.";
    }
}
