package modelo;

import tipos.TipoDobra;

/** Dobradora(o) de Avatar: Katara. */
public class Katara extends DobradorAgua {
    public Katara() {
        super("Katara", 135, 34, 18);
    }

    @Override
    protected double bonusEspecial(Dobrador alvo) {
        return 1.0;
    }
    @Override
    protected void efeitoPosAtaque(Dobrador alvo, int danoAplicado) { curar((int)Math.round(danoAplicado * 0.20)); }

    @Override
    public String descricaoHabilidade() {
        return "Cura com Água: recupera 20% do dano causado.";
    }
}
