import gui.TelaMapa;
import javax.swing.SwingUtilities;

/** Ponto de entrada da versão gráfica do jogo. */
public class JogoGUI {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaMapa tela = new TelaMapa();
            tela.setVisible(true);
        });
    }
}
