package testes;
import modelo.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ExperienciaTest {
    @Test void ganhaExperiencia() {
        Zuko z=new Zuko(); z.ganharExperiencia(50);
        assertEquals(1,z.getNivel()); assertEquals(50,z.getExperiencia());
    }
    @Test void sobeDeNivel() {
        Zuko z=new Zuko(); int ataque=z.getAtaque();
        z.ganharExperiencia(100);
        assertEquals(2,z.getNivel()); assertTrue(z.getAtaque()>ataque);
        assertEquals(z.getVidaMaxima(),z.getVida());
    }
    @Test void derrotarDaExperiencia() {
        Zuko z=new Zuko(); Dobrador alvo=new Katara();
        while(!alvo.estaDerrotada()) z.atacar(alvo);
        assertTrue(z.getExperiencia()>0 || z.getNivel()>1);
    }
}
