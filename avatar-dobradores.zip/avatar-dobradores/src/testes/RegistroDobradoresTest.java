package testes;
import modelo.*;
import sistema.RegistroDobradores;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RegistroDobradoresTest {
    @Test void naoDuplicaEspecie() {
        RegistroDobradores r=new RegistroDobradores();
        assertTrue(r.registrarComoVisto(new Katara()));
        assertFalse(r.registrarComoVisto(new Katara()));
        assertEquals(1,r.totalVistos());
    }
    @Test void recrutadoTambemContaComoVisto() {
        RegistroDobradores r=new RegistroDobradores();
        Dobrador z=new Zuko();
        assertTrue(r.registrarComoRecrutado(z));
        assertTrue(r.jaFoiVisto(z)); assertTrue(r.jaFoiRecrutado(z));
    }
}
