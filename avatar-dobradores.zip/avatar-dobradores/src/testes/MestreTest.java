package testes;
import modelo.*;
import sistema.Mestre;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MestreTest {
    @Test void equipeTemLimiteSeis() {
        Mestre m=new Mestre("Aventureiro");
        m.adicionarDobrador(new Aang()); m.adicionarDobrador(new Katara());
        m.adicionarDobrador(new Toph()); m.adicionarDobrador(new Zuko());
        m.adicionarDobrador(new Azula()); m.adicionarDobrador(new Iroh());
        assertEquals(6,m.tamanhoEquipe());
        assertFalse(m.adicionarDobrador(new Bumi()));
    }
}
