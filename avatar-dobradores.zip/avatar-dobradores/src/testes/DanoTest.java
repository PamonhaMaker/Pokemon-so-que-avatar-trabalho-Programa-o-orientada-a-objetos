package testes;
import modelo.*;
import tipos.TipoDobra;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DanoTest {
    @Test void vantagemFogoContraAr() { assertEquals(2.0, TipoDobra.FOGO.multiplicador(TipoDobra.AR)); }
    @Test void desvantagemArContraFogo() { assertEquals(0.5, TipoDobra.AR.multiplicador(TipoDobra.FOGO)); }
    @Test void neutroMesmoElemento() { assertEquals(1.0, TipoDobra.FOGO.multiplicador(TipoDobra.FOGO)); }
    @Test void terraTemVantagemContraAgua() {
        Toph t=new Toph(); Katara k=new Katara(); int vida=k.getVida();
        int dano=t.atacar(k); assertEquals(vida-dano,k.getVida()); assertTrue(dano>0);
    }
}
