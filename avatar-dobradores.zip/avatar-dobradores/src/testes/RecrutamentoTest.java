package testes;
import modelo.*;
import sistema.Recrutamento;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RecrutamentoTest {
    @Test void vidaCheiaTemChanceMinima() {
        assertEquals(0.10, Recrutamento.calcularChance(new Katara()),0.0001);
    }
    @Test void poucaVidaAumentaChance() {
        Dobrador d=new Katara();
        double cheia=Recrutamento.calcularChance(d);
        d.receberDano(100);
        assertTrue(Recrutamento.calcularChance(d)>cheia);
    }
    @Test void chanceFicaNoLimite() {
        Dobrador d=new Katara(); d.receberDano(1000);
        assertTrue(Recrutamento.calcularChance(d)<=0.90);
    }
}
