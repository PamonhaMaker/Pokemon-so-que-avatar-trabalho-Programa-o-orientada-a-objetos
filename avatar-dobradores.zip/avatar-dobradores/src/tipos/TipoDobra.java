package tipos;

/**
 * Os quatro elementos de dobra do universo de Avatar.
 * A tabela de vantagens é uma regra do jogo, criada para as batalhas.
 */
public enum TipoDobra {
    FOGO, AGUA, TERRA, AR;

    /**
     * Vantagens usadas pelo sistema de combate:
     * Fogo > Ar > Água > Fogo e Terra > Fogo? 
     * Para manter uma relação circular simples, usamos:
     * Fogo > Ar > Água > Fogo; Terra é forte contra Água e fraca contra Ar.
     */
    public double multiplicador(TipoDobra inimigo) {
        if ((this == FOGO && inimigo == AR) ||
            (this == AR && inimigo == AGUA) ||
            (this == AGUA && inimigo == FOGO) ||
            (this == TERRA && inimigo == AGUA)) return 2.0;

        if ((this == AR && inimigo == FOGO) ||
            (this == AGUA && inimigo == AR) ||
            (this == FOGO && inimigo == AGUA) ||
            (this == AGUA && inimigo == TERRA)) return 0.5;

        return 1.0;
    }
}
