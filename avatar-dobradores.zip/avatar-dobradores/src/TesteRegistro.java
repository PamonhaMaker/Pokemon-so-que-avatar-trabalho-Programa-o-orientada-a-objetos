import modelo.*;
import sistema.RegistroDobradores;

public class TesteRegistro {
    public static void main(String[] args) {
        RegistroDobradores registro = new RegistroDobradores();
        Dobrador katara1 = new Katara();
        Dobrador katara2 = new Katara();
        Dobrador zuko = new Zuko();
        Dobrador aang = new Aang();

        System.out.println("Katara #1: " + registro.registrarComoVisto(katara1));
        System.out.println("Katara #2 (mesma espécie): " + registro.registrarComoVisto(katara2));
        System.out.println("Zuko: " + registro.registrarComoVisto(zuko));
        System.out.println("Recrutando Zuko: " + registro.registrarComoRecrutado(zuko));
        System.out.println("Recrutando Aang: " + registro.registrarComoRecrutado(aang));
        registro.imprimir();
    }
}
