import modelo.*;
import sistema.Mestre;
import sistema.Recrutamento;

public class TesteMestreRecrutamento {
    public static void main(String[] args) {
        Mestre mestre = new Mestre("Aventureiro");
        mestre.adicionarDobrador(new Aang());
        mestre.adicionarDobrador(new Katara());
        mestre.adicionarDobrador(new Toph());
        mestre.adicionarDobrador(new Zuko());
        mestre.adicionarDobrador(new Azula());
        mestre.adicionarDobrador(new Iroh());
        System.out.println(mestre);
        System.out.println("Tentou adicionar 7º dobrador: " + mestre.adicionarDobrador(new Bumi()));

        Dobrador encontrado = new Katara();
        System.out.println("\n" + encontrado);
        System.out.println("Chance de recrutamento: " + Recrutamento.calcularChance(encontrado) * 100 + "%");
        new Zuko().atacar(encontrado);
        System.out.println("Depois do combate: " + encontrado);
        System.out.println("Nova chance: " + Recrutamento.calcularChance(encontrado) * 100 + "%");
    }
}
