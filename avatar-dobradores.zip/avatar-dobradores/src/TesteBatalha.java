import modelo.Dobrador;
import modelo.Zuko;
import modelo.Aang;
import sistema.Batalha;

public class TesteBatalha {
    public static void main(String[] args) {
        Dobrador zuko = new Zuko();
        Dobrador aang = new Aang();
        System.out.println(zuko + " vs " + aang);
        Batalha batalha = new Batalha(zuko, aang);
        batalha.executarAteAcabar();
        System.out.println("\nTurnos totais: " + batalha.getNumeroTurno());
    }
}
