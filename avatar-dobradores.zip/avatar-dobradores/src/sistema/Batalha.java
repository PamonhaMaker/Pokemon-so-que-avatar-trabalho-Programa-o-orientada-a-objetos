package sistema;

import modelo.Dobrador;

/**
 * Controla o turno entre duas Dobrador (equivalente à classe Batalha da
 * especificação original).
 *
 * Importante: esta classe NUNCA verifica o tipo das Dobrador (nada de
 * "if dobrador1 instanceof DobradorFogo"). Ela só chama atacar(), e cada
 * Dobrador resolve sozinha a vantagem de tipo e a habilidade especial —
 * isso é o polimorfismo em ação dentro da batalha de verdade.
 */
public class Batalha {

    private Dobrador dobrador1;
    private Dobrador dobrador2;
    private int numeroTurno;

    public Batalha(Dobrador dobrador1, Dobrador dobrador2) {
        this.dobrador1 = dobrador1;
        this.dobrador2 = dobrador2;
        this.numeroTurno = 0;
    }

    public boolean acabou() {
        return dobrador1.estaDerrotada() || dobrador2.estaDerrotada();
    }

    /** Executa um único turno: dobrador1 ataca, depois dobrador2 ataca (se ainda estiver de pé). */
    public void executarTurno() {
        if (acabou()) {
            return;
        }
        numeroTurno++;
        System.out.println("--- Turno " + numeroTurno + " ---");

        dobrador1.atacar(dobrador2);
        if (dobrador2.estaDerrotada()) {
            System.out.println(dobrador2.getNome() + " foi derrotada!");
            return;
        }

        dobrador2.atacar(dobrador1);
        if (dobrador1.estaDerrotada()) {
            System.out.println(dobrador1.getNome() + " foi derrotada!");
        }
    }

    /** Roda a batalha inteira, turno após turno, até alguém ser derrotada. */
    public void executarAteAcabar() {
        while (!acabou()) {
            executarTurno();
        }
        Dobrador vencedor = getVencedor();
        if (vencedor != null) {
            System.out.println("\n🏆 " + vencedor.getNome() + " venceu a batalha!");
        }
    }

    /** @return a Dobrador vencedora, ou null se a batalha ainda não acabou. */
    public Dobrador getVencedor() {
        if (dobrador1.estaDerrotada() && !dobrador2.estaDerrotada()) return dobrador2;
        if (dobrador2.estaDerrotada() && !dobrador1.estaDerrotada()) return dobrador1;
        return null;
    }

    public Dobrador getDobrador1() { return dobrador1; }
    public Dobrador getDobrador2() { return dobrador2; }
    public int getNumeroTurno() { return numeroTurno; }
}
