package sistema;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import modelo.Dobrador;

/** Registro de dobradores encontrados e recrutados durante a jornada. */
public class RegistroDobradores {
    private ArrayList<Dobrador> vistos = new ArrayList<>();
    private ArrayList<Dobrador> recrutados = new ArrayList<>();

    public boolean registrarComoVisto(Dobrador dobrador) {
        if (contemEspecie(vistos, dobrador)) return false;
        vistos.add(dobrador);
        return true;
    }

    public boolean registrarComoRecrutado(Dobrador dobrador) {
        registrarComoVisto(dobrador);
        if (contemEspecie(recrutados, dobrador)) return false;
        recrutados.add(dobrador);
        return true;
    }

    public boolean jaFoiVisto(Dobrador dobrador) { return contemEspecie(vistos, dobrador); }
    public boolean jaFoiRecrutado(Dobrador dobrador) { return contemEspecie(recrutados, dobrador); }

    private boolean contemEspecie(ArrayList<Dobrador> lista, Dobrador alvo) {
        for (Dobrador d : lista) if (d.getClass().equals(alvo.getClass())) return true;
        return false;
    }

    public int totalVistos() { return vistos.size(); }
    public int totalRecrutados() { return recrutados.size(); }

    public List<Dobrador> getVistos() {
        return Collections.unmodifiableList(new ArrayList<>(vistos));
    }

    public List<Dobrador> getRecrutados() {
        return Collections.unmodifiableList(new ArrayList<>(recrutados));
    }

    public void imprimir() {
        System.out.println("========== REGISTRO DE DOBRADORES ==========");
        for (Dobrador d : vistos) {
            String marca = jaFoiRecrutado(d) ? "[X]" : "[ ]";
            System.out.println(marca + " " + d.getNome() + " [" + d.getTipo() + "]");
        }
        System.out.println("Vistos: " + totalVistos() + " | Recrutados: " + totalRecrutados());
    }
}
