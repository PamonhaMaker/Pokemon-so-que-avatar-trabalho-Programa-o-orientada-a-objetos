package sistema;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import modelo.Dobrador;

/** Representa o jogador e sua equipe de até 6 dobradores. */
public class Mestre {
    private static final int TAMANHO_MAXIMO_EQUIPE = 6;
    private static final int CURAS_MAXIMAS = 3;
    private static final int CURAS_POR_TROCA = 2;

    private String nome;
    private ArrayList<Dobrador> equipe;
    private int curasRestantes;

    public Mestre(String nome) {
        this.nome = nome;
        this.equipe = new ArrayList<>();
        this.curasRestantes = CURAS_MAXIMAS;
    }

    public boolean adicionarDobrador(Dobrador dobrador) {
        if (equipeCheia()) return false;
        equipe.add(dobrador);
        return true;
    }

    public boolean removerDobrador(Dobrador dobrador) { return equipe.remove(dobrador); }
    public boolean equipeCheia() { return equipe.size() >= TAMANHO_MAXIMO_EQUIPE; }
    public int tamanhoEquipe() { return equipe.size(); }

    public List<Dobrador> getEquipe() {
        return Collections.unmodifiableList(new ArrayList<>(equipe));
    }

    public Dobrador getDobrador(int indice) {
        if (indice < 0 || indice >= equipe.size()) return null;
        return equipe.get(indice);
    }

    public Dobrador proximoDobradorDisponivel() {
        for (Dobrador d : equipe) if (!d.estaDerrotada()) return d;
        return null;
    }

    public String getNome() { return nome; }
    public int getCurasRestantes() { return curasRestantes; }
    public static int getCurasMaximas() { return CURAS_MAXIMAS; }
    public static int getCurasPorTroca() { return CURAS_POR_TROCA; }

    public boolean curarEquipe() {
        if (curasRestantes <= 0) return false;
        for (Dobrador d : equipe) d.curar(d.getVidaMaxima());
        curasRestantes--;
        return true;
    }

    /** Libera um dobrador e ganha cargas extras de cura no Templo. */
    public boolean trocarDobradorPorCura(Dobrador dobrador) {
        if (equipe.size() <= 1) return false;
        boolean removido = equipe.remove(dobrador);
        if (removido) curasRestantes += CURAS_POR_TROCA;
        return removido;
    }

    @Override
    public String toString() {
        return nome + " (" + tamanhoEquipe() + "/" + TAMANHO_MAXIMO_EQUIPE + " dobradores)";
    }
}
