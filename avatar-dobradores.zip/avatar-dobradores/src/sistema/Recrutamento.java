package sistema;

import java.util.Random;
import modelo.Dobrador;

/**
 * Sistema de recrutamento inspirado na jornada de Avatar.
 * Quanto mais cansado/ferido estiver o oponente, maior a chance
 * de convencê-lo a entrar para a equipe.
 */
public class Recrutamento {
    private static final double CHANCE_MINIMA = 0.10;
    private static final double CHANCE_MAXIMA = 0.90;
    private static final Random random = new Random();

    public static double calcularChance(Dobrador alvo) {
        double chance = 0.80 - (0.70 * alvo.percentualVida());
        if (chance < CHANCE_MINIMA) chance = CHANCE_MINIMA;
        if (chance > CHANCE_MAXIMA) chance = CHANCE_MAXIMA;
        return chance;
    }

    public static boolean tentar(Dobrador alvo) {
        return random.nextDouble() < calcularChance(alvo);
    }
}
